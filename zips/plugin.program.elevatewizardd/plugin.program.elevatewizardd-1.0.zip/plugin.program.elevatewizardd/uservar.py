import xbmcaddon



excludes  = ['plugin.video.elevatewizardd']
